<?php
session_start();
include_once('../models/conexion.php');
include_once('../models/funciones.php');
include_once('./funciones.php');

if(isset($_POST['I_U']) && $_POST['I_U'] == 1) {
    $usuario = $_POST['usuario'];
    $passw = password_hash($_POST['passw'], PASSWORD_DEFAULT);
    $email = $_POST['email'];
    $rol = $_POST['rol'];

    $tabla = "usuarios";
    $campos = "usuario, passw, email, idrol";
    $valores = "'$usuario', '$passw', '$email', '$rol'";

    $insert = crud("INSERT INTO $tabla ($campos) VALUES ($valores)", "i");

    if($insert){
        $_SESSION['mensaje'] = "Usuario registrado correctamente";

    }else{
        $_SESSION['mensaje'] = "No se pudo registrar el Usuario, Intentelo nuevamente...";
    }
    header("Location: ../views/usuarios/index.php");
    exit();

    }
    
    if(isset($_POST['U_U']) && $_POST['U_U'] == 1){
        $idusuario = $_POST['idusuario'];

$usuario = $_POST['usuario'];

if(!empty($_POST['passw'])) {

$passw + password_hash ($_POST['passw'], PASSWORD_DEFAULT);

}

    $email = $_POST['email'];
    $rol = $_POST['rol'];
    $estado = $_POST['estado'];
    $tabla = "usuarios";
    if(!empty($_POST['passw'])){
        $campos = "usuario='$usuario', passw='$passw', email='$email', idrol='$rol', estado='$estado'";

    }else{
        $campos = "usuario='$usuario', email='$email', idrol='$rol', estado='$estado'";
    }



    $condicion = "idusuario=$idusuario";
    $update = CRUD ("UPDATE $tabla SET $campos WHERE $condicion", "u");
    if($update) {
    $_SESSION['mensaje'] = "Usuario actualizado correctamente";
    } else{
    $_SESSION['mensaje'] = "Error al actualizar el usuario";
    }
        header("Location: ../views/usuarios/index.php");
    exit();
}
?>