<?php  
    include_once('./controllers/IndexControllers.php');
    include_once('./models/conexion.php');

    $conex = new Conexion();
    $conex->getConexion();
    
    $index = new Index();
    $index->base();
