<?php 
    $dataRoles = crud("SELECT * FROM roles WHERE estado != 0","s") 
?>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Usuario: </b>
  </span>
  <input type="text" class="form-control" name="usuario" placeholder="Ingrese el nombre de Usuario" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text" id="basic-addon1">
    <b>Contraseña: </b>
  </span>
  <input type="text" class="form-control" name="passw" placeholder="Ingrese la contraseña" required>
</div>

<div class="input-group mb-3">
  <span class="input-group-text">
    <b>Email: </b>
  </span>
  <textarea class="form-control" name="email" placeholder="Ingrese el Email" required></textarea>
</div>

<div class="input-group mb-3">
  <label class="input-group-text" for="inputGroupSelect01">
    <b>Rol: </b>  
  </label>

  <select class="form-select" id="rol" name="rol" required>
    <option value="" selected>Seleccione un rol</option>

    <?php foreach($dataRoles AS $resultRol): ?>
        <option value="<?= $resultRol['idrol'] ?>"><?= $resultRol['rol'] ?></option>
    <?php endforeach ?>

  </select>
</div>

<input type="hidden" name="I_U" value="1">