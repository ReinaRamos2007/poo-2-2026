
<?php
        session_start();
        include"../../models/conexion.php";
        include"../../models/funciones.php";
        include"../../controllers/funciones.php";

       

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Panel Usuario</title>
    <!-- Bootstrap CSS -->
    <link rel="shortcut icon" href="../../public/img/crud.png" type="image/x-icon">
    <link rel="stylesheet" href="../../public/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../public/css/alertify.css">
    <link rel="stylesheet" href="../../public/css/default.css">
    <link rel="stylesheet" href="../../public/css/inputmask.min.css">
    <link rel="stylesheet" href="../../public/css/style.css">
    <!-- JS -->
    <script src="../../public/js/jquery-3.7.1.min.js"></script>
    <script src="../../public/js/bootstrap.bundle.min.js"></script>
    <script src="../../public/js/alertify.js"></script>
    <script src="../../public/js/inputmask.min.js"></script>
    <script src="../../public/js/jquery.inputmask.bundle.js"></script>
    <script src="../../public/js/fontawesome.js"></script>
</head>  
<body id="toor">
    <div class="card mt-3 container">
        <div class="card-header d-flex justify-content-between align-items-center">
            <p><b>Panel de Usuario</b></p>

            <a href="../../index.php" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-circle-arrow-left"></i>
            </a>
        </div>
        <div class="card-body">
            <?php

            include './tabla.php'; 

            ?>
        </div>
    </div>
</body>
</html>
