<?php
class Conexion{
    private $pdo;
    private $dsn = 'mysql:host=localhost;dbname=crud;charset=utf8mb4';
    private $user = 'toor';
    private $pass = 'toor';

    public function __construct()
    {
        try{
            $this->pdo = new PDO(
                $this->dsn,
                $this->user,
                $this->pass
            );

            $this->pdo->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            //echo "Conexion exitosa...";
        } catch(PDOException $e){
            echo "Error: ".$e->getMessage();
        }
    }

    public function getConexion(){
        return $this->pdo;
    }

    public function closeConexion(){
        $this->pdo = null;
    }
}